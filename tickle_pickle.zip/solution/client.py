import os
import pickle
from cryptography.fernet import Fernet
import re

#key is generated with fernet. 
#Command "Fernet.generate_key()"
key = "rP_MI8rQjqQXxN8XfvNsgFpIioBvNLqecqjUy38mqBQ="


#check for empty or special chars in username
def san(un,pas):
    regex = "['+<>@#$&%!(){}]"

    p=re.compile(regex)


    #check for empty username or password
    if(len(un) == 0 or len(pas) == 0):

        print("Username OR Password can not be empty")
        user_input()

    #check for spcial chars in username
    else:
        if(re.search(p, un)):
            print("Username can not contain sepcial chars")
            user_input()            

        else:
            encrypt(un,pas)



#take input from user
def user_input():
    u = input("Username : ")
    p = input("Password : ")

    san(u,p)



#encrypt password with key
def encrypt(u,p):
    
    fernet = Fernet(key)
    encP = fernet.encrypt(p.encode())

    yo_fun = fun(u,encP)
    

#save in file

def fun(name,password):
    s = {"username":name,"password":password}
    safecode = pickle.dumps(s)
    with open("users.json","wb") as f:
        f.write(safecode)
    return safecode

if __name__ == '__main__':
    user_input()

