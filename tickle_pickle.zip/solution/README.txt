1. Input username taking from client is not sanitized. 

2 Such input can casue "SQLI", "command injection", and if Username is reflected on any web page then can casues "XSS", "Server Side Template Injection".

3. Password is passed to server and stored in plain text.

4. Such plain text password is easily visible to attacker if gain access to database


Solution

1. In solution it check if username contain special chars.

2. The password is encrypted and then stored in file.

Thank you