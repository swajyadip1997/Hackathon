1. I write exploit in Bash script, you need to run this file in linux terminal.

2. I have original "question.cpp" in folder

3. To run exploit the "question.cpp" and "exploit.sh" should be in same directory or folder


#### Requirements to Run exploit ####

User just need to have g++ compiler install on machine


### How Exploit works ###

1. In the given program input for "Enter the count of numbers?" in stored in "int num" variable

2. The capacity of "int" variable is "4 bytes" and range is "−2147483648 to 2147483647". Means "num" variable can store maximum value  "2147483647".

3. So to cause buffer overflow we need to enter value more than "4 bytes" or "2147483647" .

4. In given exploit input to variable "num" is "2147483648" which cause buffer overflow and crash the program.


Thank You



